package btscoconnect.sample.avcmms.com.btscoconnectsample;

/**
 * Created by skobayashi on 14/08/04.
 */
public class ConnectionData {

    private String deviceName;
    private String deviceAddr;

    public String getDeviceAddr() {
        return deviceAddr;
    }

    public void setDeviceAddr(String deviceAddr) {
        this.deviceAddr = deviceAddr;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }
}
